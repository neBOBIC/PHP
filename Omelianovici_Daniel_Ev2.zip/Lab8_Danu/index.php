<h1>Biblioteca</h1>
<a href="insert_carti.php">Insereaza Carti</a><br>
<a href="afisari_carti.php">Afisari Carti</a><br>
<a href="add_user.php">Adauga Utilizator</a><br>
<a href="afisari_useri.php">Afisari Utilizatori</a><br>
