<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Welcome!</title>
</head>
<body>
    <div class="container">
        <h1>Welcome to our store!</h1>

        <div class="button">
            <a href="comanda.php"><button>Plasează o comandă</button></a>
        </div>

        <div class="button">
            <a href="vizualizare.php"><button>Vizualizare comenzi</button></a>
        </div>
    </div>
</body>
</html>
